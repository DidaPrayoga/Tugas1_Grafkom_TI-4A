function setup() {
  createCanvas(640, 480);
}

function draw() {
background(128,220,0);
rect(160, 120, 260, 20);
ellipse(140, 136, 190, 190);
}